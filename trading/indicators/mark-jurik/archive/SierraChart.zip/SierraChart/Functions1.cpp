#include "C:\SierraChart\ACS_Source\sierrachart.h"
#include "math.h"

SCDLLName("JMA")

int IntPortion( float Paramet) 
{
	return int ( Paramet > 0.0f ? floor (Paramet) : ceil (Paramet));
}

SCSFExport scsf_Jurik(SCStudyGraphRef sc)
{
  
  int ii = 0;      
  SCInputRef Length = sc.Input[ii++];
  SCInputRef Phase = sc.Input[ii++];
  SCInputRef InputData = sc.Input[ii++];
  
  SCSubgraphRef JMA = sc.Subgraph[0];
  SCFloatArrayRef JMAValueBuffer = sc.Subgraph[0].Arrays[0];
  SCFloatArrayRef fC0Buffer = sc.Subgraph[0].Arrays[1];
  SCFloatArrayRef fA8Buffer = sc.Subgraph[0].Arrays[2];
  SCFloatArrayRef fC8Buffer = sc.Subgraph[0].Arrays[3];
  
  if (sc.SetDefaults)
  {
    sc.GraphName = "JMA";
    sc.StudyDescription = "JMA";
    sc.GraphRegion = 0;
    sc.DrawZeros = 0;  
    sc.GraphDrawType = GDT_CUSTOM;

    sc.FreeDLL = 1;
    sc.AutoLoop = 0;
    
    JMA.Name = "JMA";
    JMA.DrawStyle = DRAWSTYLE_LINE;
    JMA.LineWidth = 1;
    JMA.PrimaryColor = RGB(128,0,128);
    
    Length.Name = "Length";
		Length.SetInt(20);
		
		Phase.Name = "Phase";
		Phase.SetFloat(0.0);
		
		InputData.Name = "Input Data";
		InputData.SetInputDataIndex(SC_LAST);
                
    return;
  }

	float list[128];
	float ring1[128];
	float ring2[128];
	float buffer[128];
	
	
	float& dValue =  sc.PersistVars->f3;
	float& sValue =  sc.PersistVars->f4;
	float& absValue =  sc.PersistVars->f5;
	float& highDValue =  sc.PersistVars->f6;
	float& lowDValue =  sc.PersistVars->f7;
	float& intPart =  sc.PersistVars->f9;
	float& series=  sc.PersistVars->f10;
	float& paramA=  sc.PersistVars->f11;
	float& paramB=  sc.PersistVars->f12;
	float& sqrtParam=  sc.PersistVars->f14;
	float& lengthDivider=  sc.PersistVars->f15;;
	float& phaseParam=  sc.PersistVars->f16;
	float& lengthParam=  sc.PersistVars->f1;
	float& JMAValue =  sc.PersistVars->f2;
	float& loopCriteria =  sc.PersistVars->f8;
	float& cycleDelta =  sc.PersistVars->f13;
	float& JMATempValue =  sc.PersistVars->f14;

	int& s68 =  sc.PersistVars->i1;
	int& s58 = sc.PersistVars->i2;
	int& s38 = sc.PersistVars->i3;
	int& s40 = sc.PersistVars->i4;
	int& s60 = sc.PersistVars->i5;
	
	int& leftInt = sc.PersistVars->i6;
	int& rightPart = sc.PersistVars->i7;
	int& upShift = sc.PersistVars->i8;
	int& dnShift = sc.PersistVars->i9;
	int& loopParam = sc.PersistVars->i10;
	int& diffFlag = sc.PersistVars->i11;
	int& highLimit =sc.PersistVars->i12;
	int& cycleLimit = sc.PersistVars->i13;
	int& counterA = sc.PersistVars->i14;
	int& counterB = sc.PersistVars->i15;
	int limitValue = 0;
	int startValue = 0;
	
	
	
	for (int i = 0; i <= limitValue; i++) list[i] = -1000000; 
	for (int i = startValue; i <= 127; i++) list[i] = 1000000;
	 
	bool initFlag  = true;
	lengthParam = ( Length.GetInt() < 1.0000000002 ? 0.0000000001f : (Length.GetInt() - 1.0f) / 2.0f);
		
	if ( Phase.GetFloat() < -100.0f) 
		phaseParam = 0.5f;
	else
	{
		if (Phase.GetFloat() > 100.0f) 
			phaseParam = 2.5f;
		else 
			phaseParam = Phase.GetFloat() / 100.0f + 1.5f;
	}
	
	float logParam = float( log( sqrt (lengthParam)) / log (2.0f));
	
	logParam = (  logParam < -2.0f ? 0.0f : logParam + 2.0f);
		 
	sqrtParam = sqrt( lengthParam) * logParam; 
	lengthParam   *= 0.9f; 
	lengthDivider = lengthParam / (lengthParam + 2.0f);

	
 
	for ( int shift = 0; shift < sc.ArraySize; shift++) 
	{
		series = sc.BaseData[InputData.GetInputDataIndex()][shift];
		if ( loopParam < 61) 
		{ 
			loopParam++; 
			buffer[ loopParam] = series; 
		} 
		if (loopParam > 30) 
		{
			if ( initFlag) 
			{ 
				initFlag = false;
				diffFlag = 0; 
				for ( int i = 1; i <= 29; i++) 
				{ 
					if (buffer[i + 1] != buffer[i]) 
						diffFlag = 1;
				}  
				highLimit = diffFlag * 30;

				if ( highLimit == 0) 
					paramB = series;
				else 
					paramB = buffer[1];

				paramA = paramB; 
				if (highLimit > 29) 
					highLimit = 29; 
			} 
			else 
				highLimit = 0;

			for (int i = highLimit; i >= 0; i--) 
			{ 
				if (i == 0) 
					sValue = series; 
				else 
					sValue = buffer[31 - i];
				
				if ( abs(sValue - paramA) > abs (sValue - paramB)) 
					absValue = abs(sValue - paramA); 
				else 
					absValue = abs(sValue - paramB);

				dValue = absValue + 0.0000000001f; 

				if ( counterA <= 1) counterA = 127; else counterA--; 
				if ( counterB <= 1) counterB = 10;  else counterB--; 
				if ( cycleLimit < 128) cycleLimit++; 

				cycleDelta += dValue - ring2[ counterB]; 
				ring2[ counterB] = dValue; 

				if ( cycleLimit > 10) 
					highDValue = cycleDelta / 10.0f; 
				else 
					highDValue = cycleDelta / cycleLimit; 

				if ( cycleLimit > 127) 
				{ 
					dValue = ring1[ counterA]; 
					ring1[counterA] = highDValue; 
					s68 = 64; 
					s58 = s68; 
					while (s68 > 1) 
					{ 
						if ( list[s58] < dValue) 
						{ 
							s68 /= 2; 
							s58 += s68; 
						} 
						else 
						{
							if ( list[s58] <= dValue) 
								s68 = 1; 
							else 
							{ 
								s68 /= 2; 
								s58 -= s68; 
							}
						}
					} 
				} 
				else 
				{
					ring1[ counterA] = highDValue; 
					if ( (limitValue + startValue) > 127) 
					{
						startValue--; 
						s58 = startValue; 
					} 
					else 
					{
						limitValue++; 
						s58 = limitValue; 
					}
					if ( limitValue > 96)	s38 = 96;	else s38 = limitValue; 
					if ( startValue < 32)	s40 = 32;	else s40 = startValue; 
				}
				//----		      
				s68 = 64; 
				s60 = s68; 
				while ( s68 > 1) 
				{
					if ( list[s60] >= highDValue) 
					{
						if ( list[s60 - 1] <= highDValue) 
						{
							s68 = 1; 
						}
						else 
						{
							s68 /= 2; 
							s60 -= s68; 
						}
					}
					else 
					{
						s68 /= 2; 
						s60 += s68;
					}

					if ((s60 == 127) && (highDValue > list[127])) 
						s60 = 128; 
				} // while

				if (cycleLimit > 127) 
				{
					if ( s58 >= s60) 
					{
						if (((s38 + 1) > s60) && ((s40 - 1) < s60)) 
							lowDValue += highDValue; 
						else 
						{
							if ((s40 > s60) && ((s40 - 1) < s58)) 
								lowDValue += list[ s40 - 1]; 
						}
					}
					else
					{
						if (s40 >= s60) 
						{
							if (((s38 + 1) < s60) && ((s38 + 1) > s58)) 
								lowDValue += list[s38 + 1]; 
						}
						else 
							if ((s38 + 2) > s60) 
								lowDValue += highDValue; 
							else 
								if (((s38 + 1) < s60) && ((s38 + 1) > s58)) 
									lowDValue += list[s38 + 1]; 
					}

					if (s58 > s60) 
					{
						if (((s40 - 1) < s58) && ((s38 + 1) > s58)) 
							lowDValue += list[s58]; 
						else 
							if ((s38 < s58) && ((s38 + 1) > s60)) 
								lowDValue -= list[s38]; 
					}
					else 
					{
						if (((s38 + 1) > s58) && ((s40 - 1) < s58)) 
							lowDValue -= list[s58]; 
						else 
							if ((s40 > s58) && (s40 < s60)) 
								lowDValue -= list[s40]; 
					}
				}

				if (s58 <= s60) 
				{
					if (s58 >= s60) 
						list[s60] = highDValue; 
					else 
					{
						for ( int j = s58 + 1; j <= (s60 - 1); j++) 
							list[j - 1] = list[j]; 
						list[s60 - 1] = highDValue; 
					}
				} 
				else 
				{
					for (int j = s58 - 1; j >= s60; j--) 
						list[j + 1] = list[j]; 
					list[s60] = highDValue; 
				}

				if (cycleLimit <= 127) 
				{
					lowDValue = 0; 
					for (int j = s40; j <= s38; j++) 
					{
						lowDValue = lowDValue + list[j]; 
					}
				}
				//----			    
				if ((loopCriteria + 1) > 31) loopCriteria = 31; else loopCriteria++; 
				JMATempValue = sqrtParam / (sqrtParam + 1.0f);
				float sqrtDivider = JMATempValue;

				if (loopCriteria <= 30) 
				{
					if (sValue - paramA > 0) paramA = sValue; else paramA = sValue - (sValue - paramA) * sqrtDivider; 
					if (sValue - paramB < 0) paramB = sValue; else paramB = sValue - (sValue - paramB) * sqrtDivider; 
					JMATempValue = series;

					if (loopCriteria == 30) 
					{ 
						fC0Buffer[shift] = series;
  
						if ( ceil(sqrtParam) >= 1) intPart = ceil(sqrtParam); else intPart = 1; 
						leftInt = IntPortion( intPart); 

						if ( floor(sqrtParam) >= 1) intPart = floor(sqrtParam); else intPart = 1; 
						rightPart = IntPortion(intPart);
						
						if ( leftInt == rightPart)
							dValue = 1.0f;
						else 
							dValue = (sqrtParam - rightPart) / (leftInt - rightPart);

						if ( rightPart <= 29) 
							upShift = rightPart; 
						else 
							upShift = 29;

						if (leftInt <= 29)   dnShift = leftInt; else dnShift = 29; 
						fA8Buffer[shift] = 
							(series - buffer[loopParam - upShift]) *
							(1 - dValue) / rightPart + 
							(series - buffer[loopParam - dnShift]) * 
							dValue / leftInt;
					}
				} 
				else 
				{
					float powerValue;
					dValue = lowDValue / (s38 - s40 + 1);
					if ( logParam >= 2.5f) 
						 powerValue = logParam - 2.0f;
					else 
						 powerValue = 0.5f;

					float tmp_pow = pow( absValue/dValue, powerValue);

					if ( logParam >= tmp_pow) 
						dValue = tmp_pow; 
					else 
						dValue = logParam; 

					if (dValue < 1) 
						dValue = 1;

					powerValue = pow( sqrtDivider, sqrt (dValue)); 
					if (sValue - paramA > 0) paramA = sValue; else paramA = sValue - (sValue - paramA) * powerValue; 
					if (sValue - paramB < 0) paramB = sValue; else paramB = sValue - (sValue - paramB) * powerValue; 
				}
			}
			if ( loopCriteria > 30) 
			{
				JMATempValue = JMAValueBuffer[shift - 1];
				float powerValue   = pow( lengthDivider, dValue);
				float squareValue  = powerValue * powerValue;
				fC0Buffer[shift] = 
					(1 - powerValue) * 
					series + powerValue * fC0Buffer[shift - 1];
				fC8Buffer[shift] = 
					(series - fC0Buffer[shift]) * 
					(1 - lengthDivider) + lengthDivider * fC8Buffer[shift - 1];
				fA8Buffer[shift] = 
					(phaseParam * fC8Buffer[shift] + 
						fC0Buffer[shift] - JMATempValue) * 
						(powerValue * (-2.0f) + squareValue + 1) + 
					squareValue * fA8Buffer[shift - 1];  
				JMATempValue = JMATempValue + fA8Buffer[shift]; 
			}
			JMAValue = JMATempValue;
		}

		if ( loopParam <= 30) 
			JMAValue = sc.BaseData[InputData.GetInputDataIndex()][sc.ArraySize-1];

		JMAValueBuffer[shift] = JMAValue;
		JMA[shift] = JMAValueBuffer[shift];
	} 
	
}


