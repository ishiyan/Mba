using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;

namespace NinjaTrader.Indicator
{
    /// <summary>
    /// John Ehlers Corona Indicators 
    /// ported to NT by sefstrat 
    /// </summary>
    [Description("Corona Trend Vigor")]
    [Gui.Design.DisplayName(" Corona TrendVigor")]
    public class CoronaTrendVigor : Indicator
    {
        #region Variables
        
        private DataSeries _domCyc;
        private DataSeries _domCycMdn;
        private DataSeries _smoothHP;
        private DataSeries _highPass;
        private DataSeries _bandPass;
        private DataSeries _ratio;

        private Color[] _colors;
        private Dictionary<int, FilterBank[]> _filters;
        private FilterBank[] bank
        {
            get { return _filters[CurrentBar]; }
        }
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
	
            Add(new Plot(new Pen(Color.FromArgb(150,60,120,255), 3), "vigor"));

            _filters = new Dictionary<int, FilterBank[]>();


            #region Colors
            _colors= new Color[21];		
            for (int n = 0; n <= 10; n++)
            {
                int c1 = 60 - (6 * n);
                int c2 = 120 - (12 * n);
                _colors[n] = Color.FromArgb(c1, c2, 255);
            }
            for (int n = 11; n <= 20; n++)
                _colors[n] = Color.FromArgb(0, 0, (int)(255 * (2 - n / 10d))); 
            #endregion

            #region DataSeries
            _domCyc = new DataSeries(this);
            _highPass = new DataSeries(this);
            _smoothHP = new DataSeries(this);
            _domCycMdn = new DataSeries(this);
            _bandPass = new DataSeries(this);
            _ratio = new DataSeries(this);
            #endregion

            CalculateOnBarClose = true;
            Overlay = false;
            PriceTypeSupported = false;
        }


        protected override void OnBarUpdate()
        {
            if (CurrentBar < 12) return;

            double alpha = (1 - Math.Sin(twoPi / 30)) / Math.Cos(twoPi / 30);

            if (CurrentBar == 12)
            {           
                FilterBank[] b = new FilterBank[60];
                for (int n = 1; n < 60; n++)
                    b[n] = new FilterBank();
                _filters[12] = b;

                for(int bar = 1; bar < CurrentBar; bar++)
                {
                    _highPass[bar] = 0.5 * (1 + alpha)* Momentum(Input, 1)[bar] + alpha * _highPass[bar+1];
                }
            }
            else
            {
                _highPass[0] = 0.5 * (1 + alpha)* Momentum(Input, 1)[0] + alpha * _highPass[1];
                FilterBank[] b = new FilterBank[60];
                for (int n = 1; n < 60; n++)
                    b[n] = (FilterBank)_filters[CurrentBar - 1][n].Clone();
                _filters[CurrentBar] = b;
            }
				          
            _smoothHP[0] = (_highPass[0] + 2 * _highPass[1] + 3 * _highPass[2] + 3 * _highPass[3] + 2 * _highPass[4] + _highPass[5]) / 12;

            double maxAmpl = 0d;
            double delta = -0.015 * CurrentBar + 0.5;
            delta = delta < 0.1 ? 0.1 : delta;
			

            for (int n = 11; n < 60; n++)
            {
                double beta = Math.Cos(4*Math.PI / (n+1));
                double gamma = 1 / Math.Cos(8*Math.PI * delta / (n+1));
                double a = gamma - Math.Sqrt(gamma * gamma - 1);
                bank[n].Q[0] = (_smoothHP[0] - _smoothHP[1]) * ((n+1)/4/Math.PI);
                bank[n].I[0]= _smoothHP[0];
                bank[n].R[0]= 0.5 * (1 - a) * (bank[n].I[0]- bank[n].I[2]) + beta * (1 + a) * bank[n].R[1] - a * bank[n].R[2];
                bank[n].Im[0] = 0.5 * (1 - a) * (bank[n].Q[0] - bank[n].Q[2]) + beta * (1 + a) * bank[n].Im[1] - a * bank[n].Im[2];
                bank[n].Amplitude = bank[n].R[0]* bank[n].R[0]+ bank[n].Im[0] * bank[n].Im[0];

                maxAmpl = bank[n].Amplitude > maxAmpl ? bank[n].Amplitude : maxAmpl;
            }
			

            double num = 0; double den = 0;
            for (int n = 11; n < 60; n++)
            {
                bank[n].I[2] = bank[n].I[1];
                bank[n].I[1] = bank[n].I[0];
                bank[n].Q[2] = bank[n].Q[1];
                bank[n].Q[1] = bank[n].Q[0];
                bank[n].R[2] = bank[n].R[1];
                bank[n].R[1] = bank[n].R[0];
                bank[n].Im[2] = bank[n].Im[1];
                bank[n].Im[1] = bank[n].Im[0];
                bank[n].dB[1] = bank[n].dB[0];

                if (maxAmpl != 0 && bank[n].Amplitude / maxAmpl > 0){
                    bank[n].dB[0] = -10 * Math.Log(.01 / (1 - 0.99 * bank[n].Amplitude / maxAmpl)) / Math.Log(10);
                }

                bank[n].dB[0] = 0.33 * bank[n].dB[0] + 0.67 * bank[n].dB[1];
                bank[n].dB[0] = bank[n].dB[0] > 20 ? 20 : bank[n].dB[0];

                if (bank[n].dB[0] <= 6)
                {
                    num += n * (20 - bank[n].dB[0]);
                    den += (20 - bank[n].dB[0]);
                }
                if (den != 0) _domCyc.Set(0.5 * num / den);
            }

            _domCycMdn[0] = GetMedian(_domCyc, 5);
            _domCycMdn[0] = _domCyc[0] < 6 ? 6 : _domCyc[0];

            double delta2 = .1;
            double beta2 = Math.Cos(twoPi / _domCycMdn[0]);
            double g2 = 1 / Math.Cos(fourPi * delta2 / _domCycMdn[0]);
            double alpha2 = g2 - Math.Sqrt(g2 * g2 - 1);
            _bandPass[0] = 0.5 * (1 - alpha2) * (Input[0] - Input[2])
                + beta2 * (1 + alpha2) * _bandPass[1] - alpha2 * _bandPass[2];
            //Quadrature component is derivative of InPhase component divided by omega
            double Q2 = (_domCycMdn[0] / twoPi) * (_bandPass[0] - _bandPass[1]);


            //Pythagorean theorem to establish cycle amplitude
            double Ampl2 = Math.Sqrt(_bandPass[0] * _bandPass[0] + Q2 * Q2);

            //Trend amplitude taken over the cycle period
            int cycPeriod = (int)(_domCycMdn[0] - 1);
            if( cycPeriod < 12 ) cycPeriod = 12;
            double Trend = Input[0] - Input[Math.Min(cycPeriod, CurrentBar)];
            if( Trend != 0 && Ampl2 != 0 ) 
                _ratio[0] = 0.33 * Trend /Ampl2 + 0.67 * _ratio[1];
            if( _ratio[0] > 10 ) _ratio[0] = 10d;
            if( _ratio[0] < -10 ) _ratio[0] = -10d;

            double tv = 0.05 * (_ratio[0] + 10d);
            double widthTV = 0;
            if (tv < 0.3 || tv > 0.7) widthTV = 0.01;
            if (tv >= 0.3 && tv < 0.5) widthTV = tv - 0.3;
            if (tv >= 0.5 && tv <= 0.7) widthTV = 0.7 - tv;
           
            Value.Set(20d * tv - 10d);

            //Determine Corona Raster values
            int tv50 = (int)Math.Round(50 * tv);
            for (int n = 1; n < 51; n++)
            {
                bank[n].Raster[1] = bank[n].Raster[0]; 
                bank[n].Raster[0] = 20d;
                if( n < tv50 ) 
                    bank[n].Raster[0] = 0.8 * (Math.Pow((20 * tv - 0.4 * n) / widthTV, 0.85) + 0.2 * bank[n].Raster[1]);
                else if( n > tv50 )  
                    bank[n].Raster[0] = 0.8 * (Math.Pow((-20 * tv + 0.4 * n) / widthTV, 0.85) + 0.2 * bank[n].Raster[1]);
                else if( n == tv50 )
                    bank[n].Raster[0] = 0.5 * bank[n].Raster[1];
                if( bank[n].Raster[0] < 0 ) bank[n].Raster[0] = 0;
                if( bank[n].Raster[0] > 20 || tv < 0.3 || tv > 0.7 ) bank[n].Raster[0] = 20;
            }
        }

        public override void GetMinMaxValues(ChartControl chartControl, ref double min, ref double max)
        {
            min = -10;
            max = 10;
            return;
        }
		
        public override void Plot(Graphics graphics, Rectangle bounds, double min, double max)
        {
            drawCorona(graphics, bounds, min, max);
            base.Plot(graphics, bounds, min, max);
        }

        private void drawCorona(Graphics graphics, Rectangle bounds, double min, double max)
        {
            if (base.Bars != null)
            {
                int barPaintWidth = ChartControl.ChartStyle.GetBarPaintWidth(ChartControl.BarWidth);
                SmoothingMode smoothingMode = graphics.SmoothingMode;
                graphics.SmoothingMode = SmoothingMode.AntiAlias;

                int bars = ChartControl.BarsPainted;
                double y1;
                double vscale = bounds.Height / ChartControl.MaxMinusMin(max, min);
                Exception caughtException;
                while (bars >= 0)
                {
                    int index = ChartControl.LastBarPainted - ChartControl.BarsPainted + 1 + bars;
                    if (ChartControl.ShowBarsRequired || ((index - base.Displacement) >= base.BarsRequired))
                    {
                        try
                        {
                            double x1 = (((ChartControl.CanvasRight - ChartControl.BarMarginRight) - (barPaintWidth / 2))
                                         - ((base.ChartControl.BarsPainted - 1) * base.ChartControl.BarSpace))
                                        + (bars * (base.ChartControl.BarSpace));
                            for (int i = 1; i < 51; ++i)
                            {
                                double v = .4*i-10;
                                y1 = (bounds.Y + bounds.Height) - (int)((v - min) * vscale + 0.5);
                                double y2 = (bounds.Y + bounds.Height) - (int)((v + 1 - min) * vscale + 0.5);
                                SolidBrush brush = new SolidBrush(_colors[(int) Math.Round(_filters[index][i].Raster[0])]);
                                int width = (int)(barPaintWidth + ChartControl.BarSpaceIntern);
                                graphics.FillRectangle(brush, new Rectangle((int)x1 - width / 2, (int)y2, width, (int)Math.Abs(y1 - y2)));
                                
                            }
                        }
                        catch (Exception exception) { caughtException = exception; }
                    }
                    bars--;
                }

                graphics.SmoothingMode = smoothingMode;
            }
        }


        #region Properties
		
        [Browsable(false)]
        [XmlIgnore()]
        public DataSeries TrendVigor
        {
            get { return Values[0]; }
        }
		
  
    

        #endregion
    
        public const double twoPi = 2 * Math.PI;
        public const double fourPi = 4 * Math.PI;
		
        protected class FilterBank : ICloneable
        {	// current, old, older
            internal double[] I = new double[3];  
            internal double[] Q = new double [3];
            internal double[] R = new double [3];
            internal double[] Im = new double[3];
            internal double Amplitude = 0;
            internal double[] dB = new double[2];
            internal double[] Raster = new double[2];

            public object Clone()
            {
                FilterBank clone = new FilterBank();

                I.CopyTo(clone.I, 0);
                Q.CopyTo(clone.Q, 0);
                R.CopyTo(clone.R, 0);
                Im.CopyTo(clone.Im, 0);
                clone.Amplitude = Amplitude;
                dB.CopyTo(clone.dB, 0);
                Raster.CopyTo(clone.Raster, 0);

                return clone;
            }
        }
    }
}
#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private CoronaTrendVigor[] cacheCoronaTrendVigor = null;

        private static CoronaTrendVigor checkCoronaTrendVigor = new CoronaTrendVigor();

        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        public CoronaTrendVigor CoronaTrendVigor()
        {
            return CoronaTrendVigor(Input);
        }

        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        public CoronaTrendVigor CoronaTrendVigor(Data.IDataSeries input)
        {
            if (cacheCoronaTrendVigor != null)
                for (int idx = 0; idx < cacheCoronaTrendVigor.Length; idx++)
                    if (cacheCoronaTrendVigor[idx].EqualsInput(input))
                        return cacheCoronaTrendVigor[idx];

            lock (checkCoronaTrendVigor)
            {
                if (cacheCoronaTrendVigor != null)
                    for (int idx = 0; idx < cacheCoronaTrendVigor.Length; idx++)
                        if (cacheCoronaTrendVigor[idx].EqualsInput(input))
                            return cacheCoronaTrendVigor[idx];

                CoronaTrendVigor indicator = new CoronaTrendVigor();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                Indicators.Add(indicator);
                indicator.SetUp();

                CoronaTrendVigor[] tmp = new CoronaTrendVigor[cacheCoronaTrendVigor == null ? 1 : cacheCoronaTrendVigor.Length + 1];
                if (cacheCoronaTrendVigor != null)
                    cacheCoronaTrendVigor.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheCoronaTrendVigor = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.CoronaTrendVigor CoronaTrendVigor()
        {
            return _indicator.CoronaTrendVigor(Input);
        }

        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        public Indicator.CoronaTrendVigor CoronaTrendVigor(Data.IDataSeries input)
        {
            return _indicator.CoronaTrendVigor(input);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.CoronaTrendVigor CoronaTrendVigor()
        {
            return _indicator.CoronaTrendVigor(Input);
        }

        /// <summary>
        /// Corona Trend Vigor
        /// </summary>
        /// <returns></returns>
        public Indicator.CoronaTrendVigor CoronaTrendVigor(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.CoronaTrendVigor(input);
        }
    }
}
#endregion
