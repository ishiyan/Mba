IKTrading
=========

Ilya Kipnis's collection of quantitative trading and computational investing functions.
Also includes demos of publicly-released ideas such as Flexible Asset Allocation and SeekingAlpha strategies.
