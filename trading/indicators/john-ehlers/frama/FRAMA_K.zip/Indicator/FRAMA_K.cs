#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
    /// </summary>
    [Description("FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers")]
    public class FRAMA_K : Indicator
    {
        #region Variables
        
		// Wizard generated variables
            private int period      = 16; // Default setting for period
            private int deviation   =  1; // Default setting for deviation
		
		// Inputs for the KAMA
		    private int period_KAMA = 10; // Default for KAMA period
		    private int fast_KAMA   =  2; // Default for KAMA fast
		    private int slow_KAMA   = 30; // Default for KAMA slow
        
		// User defined variables
			private double dimension;
		    private double alpha;
		    private double finalAlpha;
		    private double upperBand;
			private double lowerBand;
		    private double highLowRange1;
			private double highLowRange2;
			private double highLowRange3;
		    
		    private int halfPeriod;
		    
		// declare DataSeries objects
		    private DataSeries halfPeriodHigh;
			private DataSeries halfPeriodLow;
		    private DataSeries filter;
					
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Blue), PlotStyle.Line, "FRAMA_K"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Gray), PlotStyle.Line, "UpperBand"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Gray), PlotStyle.Line, "LowerBand"));
            
			CalculateOnBarClose	= true;
            Overlay				= true;
            PriceTypeSupported	= true;
			
			halfPeriodHigh   	= new DataSeries(this);
			halfPeriodLow   	= new DataSeries(this);
			filter 			    = new DataSeries(this);
			
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			//do we have enough bars?
			if (CurrentBar < 2 * Period)
				return;
			
			//define half period
			halfPeriod = Period / 2;
			
			//define the three needed ranges for calculating the fractal dimension
			highLowRange1 = ((MAX(High, Period)[0] - MIN(Low, Period)[0]) / Period);
					
			highLowRange2 = ((MAX(High, halfPeriod)[0] - MIN(Low, halfPeriod)[0]) / (halfPeriod));
			
			halfPeriodHigh.Set(High[halfPeriod]);
			halfPeriodLow.Set(Low[halfPeriod]);
	
			highLowRange3 = ((MAX(halfPeriodHigh, halfPeriod)[0] - MIN(halfPeriodLow, halfPeriod)[0]) / halfPeriod);
			
			// calculate fractal dimension for adapting the MA
			if (highLowRange1 > 0 && highLowRange2 > 0 && highLowRange3 > 0)
				dimension = (Math.Log(highLowRange3 + highLowRange2) - Math.Log(highLowRange1)) / Math.Log(2);
			
			// calculate the alpha needed for the adaptive ema in the next step
				alpha = Math.Exp(- 4.6 * (dimension - 1));
			
			// limit alpha to vary only from 0.01 to 1
			if (alpha < 0.01)
				finalAlpha = 0.01;
			else
				finalAlpha = alpha;
				
			if (alpha > 1)
				finalAlpha = 1;
			else
				finalAlpha = alpha;
			
			//final calculation of the frama filter with user changeable input series
			filter.Set(finalAlpha * Input[0] + (1 - finalAlpha) * filter[1]);
            
			//calculate KAMA filter with user changeable input series
			double filter2 = KAMA(Input, Fast_KAMA, Period_KAMA, Slow_KAMA)[0];
			
			//calculate final filter to be used for displaying and the deviation bands
			//weight is equal between both and offers a good tradeoff, but a stratgy might optimize that value for different markets / timeframes
			double filter3 = (filter2 + filter[0]) * .5;			
			
			//calculate uppper- and lowerbands
			upperBand = filter3 + (Deviation * StdDev(Period)[0]);
			lowerBand = filter3 - (Deviation * StdDev(Period)[0]);
			
			double MaxHigh = MAX(High,25)[20];
			
			//define our final plots and make sure the plot value for the first 50 bars is set to close to give the calculations time to catch up
			if (CurrentBar < 50)
			{
				Frama_K.Set(Close[0]);
				Upperband.Set(Close[0]);
            	Lowerband.Set(Close[0]);
			}
			else 
			{
				Frama_K.Set(filter3);
				Upperband.Set(upperBand);
            	Lowerband.Set(lowerBand);
			}
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Frama_K
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Upperband
        {
            get { return Values[1]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Lowerband
        {
            get { return Values[2]; }
        }

        [Description("Even number of bars used for calculations")]
        [Category("Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(2, value); }
        }

        [Description("Number of standard deviations")]
        [Category("Parameters")]
        public int Deviation
        {
            get { return deviation; }
            set { deviation = Math.Max(0, value); }
        }
		
		[Description("Number of bars used for KAMA calculations")]
        [Category("Parameters")]
        public int Period_KAMA
        {
            get { return period_KAMA; }
            set { period_KAMA = Math.Max(2, value); }
        }
		
		[Description("Number of bars used for KAMA Fast calculations")]
        [Category("Parameters")]
        public int Fast_KAMA
        {
            get { return fast_KAMA; }
            set { fast_KAMA = Math.Max(1, value); }
		}
		
		[Description("Number of bars used for KAMA Slow calculations")]
        [Category("Parameters")]
        public int Slow_KAMA
        {
            get { return slow_KAMA; }
            set { slow_KAMA = Math.Max(2, value); }
		}

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private FRAMA_K[] cacheFRAMA_K = null;

        private static FRAMA_K checkFRAMA_K = new FRAMA_K();

        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        public FRAMA_K FRAMA_K(int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            return FRAMA_K(Input, deviation, fast_KAMA, period, period_KAMA, slow_KAMA);
        }

        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        public FRAMA_K FRAMA_K(Data.IDataSeries input, int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            checkFRAMA_K.Deviation = deviation;
            deviation = checkFRAMA_K.Deviation;
            checkFRAMA_K.Fast_KAMA = fast_KAMA;
            fast_KAMA = checkFRAMA_K.Fast_KAMA;
            checkFRAMA_K.Period = period;
            period = checkFRAMA_K.Period;
            checkFRAMA_K.Period_KAMA = period_KAMA;
            period_KAMA = checkFRAMA_K.Period_KAMA;
            checkFRAMA_K.Slow_KAMA = slow_KAMA;
            slow_KAMA = checkFRAMA_K.Slow_KAMA;

            if (cacheFRAMA_K != null)
                for (int idx = 0; idx < cacheFRAMA_K.Length; idx++)
                    if (cacheFRAMA_K[idx].Deviation == deviation && cacheFRAMA_K[idx].Fast_KAMA == fast_KAMA && cacheFRAMA_K[idx].Period == period && cacheFRAMA_K[idx].Period_KAMA == period_KAMA && cacheFRAMA_K[idx].Slow_KAMA == slow_KAMA && cacheFRAMA_K[idx].EqualsInput(input))
                        return cacheFRAMA_K[idx];

            FRAMA_K indicator = new FRAMA_K();
            indicator.BarsRequired = BarsRequired;
            indicator.CalculateOnBarClose = CalculateOnBarClose;
            indicator.Input = input;
            indicator.Deviation = deviation;
            indicator.Fast_KAMA = fast_KAMA;
            indicator.Period = period;
            indicator.Period_KAMA = period_KAMA;
            indicator.Slow_KAMA = slow_KAMA;
            indicator.SetUp();

            FRAMA_K[] tmp = new FRAMA_K[cacheFRAMA_K == null ? 1 : cacheFRAMA_K.Length + 1];
            if (cacheFRAMA_K != null)
                cacheFRAMA_K.CopyTo(tmp, 0);
            tmp[tmp.Length - 1] = indicator;
            cacheFRAMA_K = tmp;
            Indicators.Add(indicator);

            return indicator;
        }

    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.FRAMA_K FRAMA_K(int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            return _indicator.FRAMA_K(Input, deviation, fast_KAMA, period, period_KAMA, slow_KAMA);
        }

        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        public Indicator.FRAMA_K FRAMA_K(Data.IDataSeries input, int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            return _indicator.FRAMA_K(input, deviation, fast_KAMA, period, period_KAMA, slow_KAMA);
        }

    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.FRAMA_K FRAMA_K(int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            return _indicator.FRAMA_K(Input, deviation, fast_KAMA, period, period_KAMA, slow_KAMA);
        }

        /// <summary>
        /// FRAMA_K combines the KAMA and FRAMA indicators by Kaufman / Ehlers
        /// </summary>
        /// <returns></returns>
        public Indicator.FRAMA_K FRAMA_K(Data.IDataSeries input, int deviation, int fast_KAMA, int period, int period_KAMA, int slow_KAMA)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.FRAMA_K(input, deviation, fast_KAMA, period, period_KAMA, slow_KAMA);
        }

    }
}
#endregion
