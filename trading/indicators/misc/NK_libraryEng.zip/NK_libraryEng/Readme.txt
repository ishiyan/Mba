
=====================================================================
|
=====================================================================

JJMASeries.mqh (version of file from 07.01.2007)
JurXSeries.mqh (version of file from 07.01.2007)
JLiteSeries.mqh (version of file from 07.01.2007)
T3Series.mqh (version of file from 07.01.2007)
ParMASeries.mqh (version of file from 07.01.2007)
LRMASeries.mqh (version of file from 07.01.2007)
ParMASeries1.mqh (version of file from 07.01.2007)
LRMASeries1.mqh (version of file from 07.01.2007)
PriceSeries.mqh (version of file from 07.01.2007)
3c_.BB_.Osc.mqh (version of file from 01.10.2006)
3c_.BB_.Osc2.mqh (version of file from 01.10.2006)
3c_.BBJ_.Osc2.mqh (version of file from 01.10.2006)
3c_.SG_.Osc.mqh (version of file from 01.10.2006)
3Color.mqh (version of file from 01.10.2006)
3ColorJ.mqh (version of file from 01.10.2006)
3Color_.Ch.mqh (version of file from 01.10.2006)
3Color_.KeltnerCh.mqh (version of file from 01.10.2006)
HTF.mqh (version of file from 01.10.2006)
HTF_.channel.mqh (version of file from 01.10.2006)
HTF_.KlChannel.mqh (version of file from 01.10.2006)
INDIccATOR_.cOUNTED.mqh (version of file from 01.07.2006)
TrendSignalSupr.mqh (version of file from 01.07.2006)
TrendSignal.mqh (version of file from 01.07.2006)

To place files into the folder: to \.MetaTrader\.ekhperts\.inchlude \

and indicators from the folders

indicators
Pluse
Digital Filter

in the folder: \.MetaTrader\.ekhperts\.indichators.

If any of these indicators has already been used earlier, then
it is necessary to remove their compiled old versions with theexpansions
ex4.
---------------------------------------------------------------------
PriceSeries.mqh - this is additional function for the recovery of theinput
candle price according to its number and number of bar.
---------------------------------------------------------------------
iPriceSeries.mqh - this is additional function for the recovery of theinput
candle price on the simvl'nomu name, tayfreymu, according to thenumber of price and the number
bar.
---------------------------------------------------------------------
3c_.BB_.Osc.mqh - this is the file, created for the maximumsimplification
writing the indicators of trichromatic diagrams with Bollinger Bands.Example
use - file 3c_.FTLM.STLM.mtsya.
---------------------------------------------------------------------
3c_.BBJ_.Osc.mqh - this is the file, created for the maximumsimplification
writing the smoothed indicators of trichromatic diagrams withBollinger
Bands. Example of use - file 3c_.FTLM.STLM.mtsya. To replace in thefile
3c_.FTLM.STLM.mtsya the line
---------------------------------------------------------------------
3c_.BB_.Osc2.mqh - this is the file, created for the maximumsimplification
writing two-indicator trichromatic diagrams with Bollinger Bands.
Example of use - file 3c_.JccccIX2.mq4.
---------------------------------------------------------------------
3c_.SG_.Osc.mqh - this is the file, created for the maximumsimplification
writing the indicators of trichromatic diagrams with the signal line.Example
use - file 3c_.JccccIX.mq4.
---------------------------------------------------------------------
3Color.mqh - this is the file, created for the maximum simplification
writing the indicators of trichromatic lines. Example of use - file
3c_.JJMA.mq4
---------------------------------------------------------------------
3ColorJ.mqh - this is the file, created for the maximumsimplification
writing the indicators of trichromatic lines. Example of use - file
3c_.JJMA.mq4 To replace in the file by 3ColorJ.mqh
---------------------------------------------------------------------
3Color_.Ch.mqh - this is the file, created for the maximumsimplification
writing the indicators of trichromatic lines and channelssimultaneously. Example
use - file 3Color_.Ch.mqh
---------------------------------------------------------------------
3Color_.KeltnerCh.mqh - this is the file, created for the the maximum
simplification in writing the indicators of trichromatic lines andchannels Of keltnera
simultaneously. Example of use - file 3Color_.Ch.mqh. In the text
indicator to replace line # include by
# include
---------------------------------------------------------------------
HTF.mqh - this is the file, created for the maximum simplification
writing the indicators, which calculate their values on the basis ofdata s
the drawing of another, larger taymfreyma. Example of use -
file J2JMA_.htf.mq4
---------------------------------------------------------------------
HTF_.channel.mqh - this is the file, created for the the maximum
simplification in writing the indicators of the channels, whichcalculate their values
on the basis of data from the graph of another, larger taymfreyma.Example
use - file J2JMA channel_.htf.mq4.
---------------------------------------------------------------------
HTF_.KlChannel.mqh - this is the file, created for the the maximum
simplification in writing the indicators of the channels Of keltnera,which calculate its
value on the basis of data from the graph of other, the larger
taymfreyma. Example of use - file J2JMA channel_.htf.mq4. In
the text of indicator to replace line # include by
# include
---------------------------------------------------------------------
TrendSignalSupr.mqh - this is the file, created for the the maximum
simplification in writing the signal of indikatorovizmeneniya oftrend. Example
use - file JJurX_.TrendSignal.mq4.
---------------------------------------------------------------------
TrendSignal.mqh - this is the file, created for the the maximum
simplification in writing the signal of indikatorovizmeneniya oftrend. Example
use - file JAC TrendSignal.mq4.
---------------------------------------------------------------------
At the folder "Digital Filter" lie the realizations of that smoothedand trichromatic,
smoothed of digital filters from Sergey il'yukshina sergey@tibet.ru
http://fx.qrz.ru/. All parameters of digital filter are calculated on
to summer, without the generators of digital filters.
---------------------------------------------------------------------
Files VGridLinesD4.LC.mq4, VGridCycle_.H4.mq4 are
cyclic reference grids for the time axis, their example
use in template timesgrids.tpl.
---------------------------------------------------------------------
The sense of the use of a last function, which goes below, remains thehearth
by a question, therefore as in the last versions Of metatreydera,build it
function IndicatorCounted() began to work how must, and the need
in INDICATOR_.COUNTED() it fell!!!
INDICATOR_.COUNTED() - this is additional function for the recovery
quantity of already calculated bars of indicator. Its chiefcharacteristic
it consists in the fact that it makes it possible not to recountindicator on
all bars with the connection to the Internet. I.e., with theconnection k
to the Internet this function in contrast to the standard function
IndicatorCounted() nevertheless returns a quantity of those calculatedto
the connection to the Internet of bars, but not zero! FunctionINDICATOR_.COUNTED()
it is intended for replacing the function IndicatorCounted(). Use
of this function in the indicators it will be especially useful forthose traders,
which use a dialap- connection, also, for purposes of the savings oftraffic only
periodically they are connected to the Internet for obtaining the newquotations.
With the value of parameter INDIccATOR_.cOUNTED.Input=0; functionreturns
a quantity of already calculated bars, with the value of theparameter
INDIccATOR_.cOUNTED.Input = 1; recording the time of the zero occurs
bar, for the calculation according to its number with the followingstart of function int
start() the full value of a quantity of already calculated bars. With
the value of parameter INDIccATOR_.cOUNTED.Input = of -1; theresetting to zero occurs
the time of zero bar, if this is necessary, with the use
operator return(- 1); for function int start(). If we use
function INDICATOR_.COUNTED() on all indicators, which are used
in treydinge, then is commercial terminal, with the connection to theInternet,
it begins to work almost instantly, also, without the hoverings onabsolutely
the unnecessary conversion of all bars on all indicators. Examples
the uses of this function in are given the text of function itself andin any
from my indicators. (JurX.mq4)
---------------------------------------------------------------------
Nikolai kositsin
farria@mail.redcom.ru
