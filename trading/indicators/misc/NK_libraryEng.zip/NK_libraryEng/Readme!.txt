


Should be considered one important detail. there are sufficiently manyindicators,
and programmers from MetaQuotes for some reason limited the quantity
the indicators, which it can use Metatreyder through the button
"indicators". In me on any metatreydere, for example, their in all
on one hundred pieces! So that contents of the folder of\.MetaTrader\.ekhperts\.indichators
should be limited only hundred indicators! Therefore as everything
nndyuki, whose numbers alphabetically higher than critical, will beall -equal
to be intercepted By metatreyderom. By most radical and only output
there will be removal from folder MetaTrader\.experts\.indicators ofall
obscene indicators. In order to be dismantled, what JJMA
indicators should be used, it is best to copy the folder
MetaTrader somewhere, to remove from it all previous indicators and
in their place to copy JJMA indicators and, naturally, not to forget
to place files from folder INCLUDE into the folder to\.MetaTrader\.ekhperts\.inchlude \.
After this, to neglect this test Metatreyder and to think that
to you it is necessary from entire this good! But here should beconsidered that fact,
that many trichromatic indicators work through the turning to their
to netrekhtsvetnomu analog. For example, indicator 3c_.J2JMA.mqh willbe
to work only in the presence in folderMetaTrader\.experts\.indicators
indicator J2JMA.mqh(.J2JMA.mq4). After this, to copy into the worker
Metateyder only those JJMA indicators, which for you are necessaryfor
work. If we nevertheless there is the need for using as much asdesired
indicators, then in that case should be hung them to the graphthrough
button "navigator", obtaining from the folder of user indicators.
On this theme there is the intelligent articlehttp://articles.mql4.com/ru/180
Now concerning the algorithm of function JJMASeries. According to allsigns,
this algorithm considers with the calculation of its value theprevious bars on
value much greater than parameter Lenght, but how it is furtherlocated
bar from that flowing, that its influence is less. Exemplary quantityof bars,
on which occurs this efekt, comprises to pyat'nadtsat' Lenght.
To all of success!
Nikolai kositsin
